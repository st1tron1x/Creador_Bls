<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['title' => 'Trade & Business SAS - Plataforma BL']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['title' => 'Trade & Business SAS - Plataforma BL']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo e($title); ?></title>
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

    <style>
        * { box-sizing: border-box; }
        body {
            font-family: Arial, Helvetica, sans-serif;
            background: #f4f5f7;
            margin: 0;
            color: #1a1a1a;
        }
        header.topbar {
            background: #1e3a5f;
            color: #fff;
            padding: 12px 24px;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        header.topbar .brand { font-weight: bold; font-size: 15px; }
        main { max-width: 1000px; margin: 24px auto; padding: 0 16px; }
        .card { background: #fff; border-radius: 6px; box-shadow: 0 1px 3px rgba(0,0,0,.1); padding: 24px; }
        .btn {
            display: inline-block; padding: 8px 18px; border-radius: 4px; border: none;
            font-size: 14px; cursor: pointer; font-weight: bold;
        }
        .btn-primary { background: #1e6fb8; color: #fff; }
        .btn-secondary { background: #e2e5e9; color: #333; }
        .btn-success { background: #2fae4e; color: #fff; }
        .btn-danger { background: #c0392b; color: #fff; }
        input, select, textarea {
            width: 100%; padding: 7px 9px; border: 1px solid #ccc; border-radius: 4px;
            font-size: 13px; font-family: inherit;
        }
        label { display: block; font-size: 12px; font-weight: bold; margin-bottom: 3px; color: #444; }
        .field { margin-bottom: 14px; }
        .grid-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 14px; }
        .error { color: #c0392b; font-size: 11px; margin-top: 3px; }
        .alert-success { background: #eafaf0; color: #1a7a3c; border: 1px solid #bfe8cc; padding: 10px 14px; border-radius: 4px; margin-bottom: 16px; }
    </style>
</head>
<body>
    <header class="topbar">
        <div style="display:flex; align-items:center; gap:24px;">
            <div class="brand">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(auth()->guard()->check()): ?>
                    <?php echo e(auth()->user()->activeCompany()->short_name ?? 'Plataforma BL'); ?>

                <?php else: ?>
                    Plataforma BL
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(auth()->guard()->check()): ?>
                <nav style="display:flex; gap:16px;">
                    <a href="<?php echo e(route('dashboard')); ?>" style="color:#fff; font-size:13px; text-decoration:none; opacity:.9;">Dashboard</a>
                    <a href="<?php echo e(route('bl.index')); ?>" style="color:#fff; font-size:13px; text-decoration:none; opacity:.9;">BL</a>
                    <!-- <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('users.manage')): ?>
                        <a href="<?php echo e(route('users.index')); ?>" style="color:#fff; font-size:13px; text-decoration:none; opacity:.9;">Usuarios</a>
                    <?php endif; ?> -->
                </nav>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
        <div style="display:flex; align-items:center; gap:14px;">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(auth()->guard()->check()): ?>
                <?php $unread = auth()->user()->unreadNotifications; ?>
                <div style="position:relative;">
                    <a href="<?php echo e(route('notifications.index')); ?>" style="color:#fff; text-decoration:none; font-size:16px; position:relative;">
                        🔔
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($unread->count() > 0): ?>
                            <span style="position:absolute; top:-6px; right:-10px; background:#c0392b; color:#fff; font-size:10px; font-weight:bold; border-radius:10px; padding:1px 5px;">
                                <?php echo e($unread->count()); ?>

                            </span>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </a>
                </div>
                <details style="position:relative;">
                    <summary style="list-style:none; cursor:pointer; color:#fff; font-size:13px; display:flex; align-items:center; gap:4px;">
                        <?php echo e(auth()->user()->name); ?> ▾
                    </summary>
                    <div style="position:absolute; right:0; top:26px; background:#fff; border-radius:6px; box-shadow:0 2px 10px rgba(0,0,0,.2); min-width:180px; z-index:50; overflow:hidden;">
                        <a href="<?php echo e(route('profile.edit')); ?>" style="display:block; padding:10px 14px; color:#333; font-size:13px; text-decoration:none; border-bottom:1px solid #eee;">Mi perfil</a>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(auth()->user()->companies()->count() > 1): ?>
                            <a href="<?php echo e(route('company.select')); ?>" style="display:block; padding:10px 14px; color:#333; font-size:13px; text-decoration:none; border-bottom:1px solid #eee;">Cambiar empresa</a>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('users.manage')): ?>
                            <a href="<?php echo e(route('users.index')); ?>" style="display:block; padding:10px 14px; color:#333; font-size:13px; text-decoration:none; border-bottom:1px solid #eee;">Usuarios</a>
                        <?php endif; ?>
                        <form method="POST" action="<?php echo e(route('logout')); ?>">
                            <?php echo csrf_field(); ?>
                            <button type="submit" style="width:100%; text-align:left; background:none; border:none; padding:10px 14px; color:#c0392b; font-size:13px; cursor:pointer;">
                                Cerrar sesión
                            </button>
                        </form>
                    </div>
                </details>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    </header>
    <main>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('success')): ?>
            <div class="alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('error')): ?>
            <div style="background:#fdecea; color:#c0392b; border:1px solid #f5c6cb; padding:10px 14px; border-radius:4px; margin-bottom:16px;"><?php echo e(session('error')); ?></div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php echo e($slot); ?>

    </main>
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>

</body>
</html><?php /**PATH /var/www/html/resources/views/components/layout.blade.php ENDPATH**/ ?>