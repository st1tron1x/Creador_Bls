<!---<div style="font-size:7.5px; width:100%; padding:2px 9mm 0; box-sizing:border-box; display:flex; justify-content:space-between; align-items:center; color:#333; font-family:Arial, Helvetica, sans-serif; border-bottom:0.5pt solid #ccc;">
    <span><strong>BL <?php echo e($bl_number); ?></strong> &nbsp;—&nbsp; <?php echo e($shipper_short); ?> &rarr; <?php echo e($consignee_short); ?></span>
    <span>Página <span class="pageNumber"></span> de <span class="totalPages"></span></span>
</div>--->

<div style="font-size:7.5px; width:100%; padding:2px 9mm 0; box-sizing:border-box; display:flex; justify-content:space-between; align-items:center; color:#333; font-family:Arial, Helvetica, sans-serif; border-bottom:0.5pt solid #ccc;">
    <span><strong>BL <?php echo e($bl_number); ?></strong> &nbsp;—&nbsp; <?php echo e($shipper_short); ?> &rarr; <?php echo e($consignee_short); ?></span>
    <span>Página <span class="pageNumber"></span> de <span class="totalPages"></span></span>
</div><?php /**PATH /var/www/html/resources/views/pdf/bill-of-lading-header.blade.php ENDPATH**/ ?>