<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => ['title' => 'BL - Listado']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'BL - Listado']); ?>
    <div class="card">
        <h2>Bills of Lading</h2>

        <form method="GET" style="margin-bottom:20px;">
            <div class="grid-2">
                <div class="field">
                    <label>Nº de BL</label>
                    <input type="text" name="bl_number" value="<?php echo e(request('bl_number')); ?>">
                </div>
                <div class="field">
                    <label>Shipper</label>
                    <input type="text" name="shipper" value="<?php echo e(request('shipper')); ?>">
                </div>
                <div class="field">
                    <label>Consignee</label>
                    <input type="text" name="consignee" value="<?php echo e(request('consignee')); ?>">
                </div>
                <div class="field">
                    <label>Puerto</label>
                    <select name="port_id">
                        <option value="">-- Todos --</option>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $ports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $port): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($port->id); ?>" <?php if(request('port_id') == $port->id): echo 'selected'; endif; ?>>
                                <?php echo e($port->code); ?> - <?php echo e($port->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </select>
                </div>
                <div class="field">
                    <label>Estado</label>
                    <select name="status">
                        <option value="">-- Todos --</option>
                        <option value="borrador" <?php if(request('status') === 'borrador'): echo 'selected'; endif; ?>>Borrador</option>
                        <option value="emitido" <?php if(request('status') === 'emitido'): echo 'selected'; endif; ?>>Emitido</option>
                        <option value="anulacion_solicitada" <?php if(request('status') === 'anulacion_solicitada'): echo 'selected'; endif; ?>>Anulación solicitada</option>
                        <option value="anulado" <?php if(request('status') === 'anulado'): echo 'selected'; endif; ?>>Anulado</option>
                    </select>
                </div>
                <div class="field">
                    <label>Desde</label>
                    <input type="date" name="date_from" value="<?php echo e(request('date_from')); ?>">
                </div>
                <div class="field">
                    <label>Hasta</label>
                    <input type="date" name="date_to" value="<?php echo e(request('date_to')); ?>">
                </div>
            </div>
            <button type="submit" class="btn btn-primary">Buscar</button>
            <a href="<?php echo e(route('bl.index')); ?>" class="btn btn-secondary">Limpiar</a>
            <a href="<?php echo e(route('bl.create')); ?>" class="btn btn-success" style="float:right;">+ Nuevo BL</a>
        </form>

        <table style="width:100%; border-collapse:collapse; font-size:13px;">
            <thead>
                <tr style="text-align:left; border-bottom:2px solid #e2e5e9;">
                    <th style="padding:8px 4px;">Nº BL</th>
                    <th>Puerto</th>
                    <th>Shipper</th>
                    <th>Consignee</th>
                    <th>Estado</th>
                    <th>Fecha</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $bills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr style="border-bottom:1px solid #f0f0f0;">
                        <td style="padding:8px 4px;"><?php echo e($bl->bl_number ?? '(borrador)'); ?></td>
                        <td><?php echo e($bl->port?->code ?? $bl->port_of_loading_text ?? '—'); ?></td>
                        <td><?php echo e(\Illuminate\Support\Str::limit($bl->shipper, 30)); ?></td>
                        <td><?php echo e(\Illuminate\Support\Str::limit($bl->consignee, 30)); ?></td>
                        <td>
                            <span style="padding:2px 8px; border-radius:10px; font-size:11px; font-weight:bold;
                                background: <?php echo e(['borrador'=>'#e2e5e9','emitido'=>'#eafaf0','anulado'=>'#fdecea','anulacion_solicitada'=>'#fff8e6'][$bl->status]); ?>;
                                color: <?php echo e(['borrador'=>'#555','emitido'=>'#1a7a3c','anulado'=>'#c0392b','anulacion_solicitada'=>'#a67c00'][$bl->status]); ?>;">
                                <?php echo e(ucfirst(str_replace('_', ' ', $bl->status))); ?>

                            </span>
                        </td>
                        <td><?php echo e($bl->created_at->format('d/m/Y')); ?></td>
                        <td><a href="<?php echo e($bl->status === 'borrador' ? route('bl.create', $bl) : route('bl.show', $bl)); ?>">
                            <?php echo e($bl->status === 'borrador' ? 'Continuar editando' : 'Ver'); ?> &rarr;
                        </a></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="7" style="padding:20px; text-align:center; color:#888;">No hay BL que coincidan con la búsqueda.</td></tr>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </tbody>
        </table>

        <div style="margin-top:16px;"><?php echo e($bills->links()); ?></div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH /var/www/html/resources/views/bl/index.blade.php ENDPATH**/ ?>