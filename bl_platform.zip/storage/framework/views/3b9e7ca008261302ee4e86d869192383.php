<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => ['title' => 'BL '.e($bl->bl_number ?? 'Borrador').'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'BL '.e($bl->bl_number ?? 'Borrador').'']); ?>
    <div class="card">
        <div style="display:flex; justify-content:space-between; align-items:center;">
            <h2><?php echo e($bl->bl_number ?? 'BL en borrador'); ?></h2>
            <span style="padding:4px 12px; border-radius:10px; font-size:12px; font-weight:bold;
                background: <?php echo e(['borrador'=>'#e2e5e9','emitido'=>'#eafaf0','anulado'=>'#fdecea','anulacion_solicitada'=>'#fff8e6'][$bl->status]); ?>;
                color: <?php echo e(['borrador'=>'#555','emitido'=>'#1a7a3c','anulado'=>'#c0392b','anulacion_solicitada'=>'#a67c00'][$bl->status]); ?>;">
                <?php echo e($bl->status === 'anulacion_solicitada' ? 'En revisión (anulación)' : ucfirst($bl->status)); ?>

            </span>
        </div>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($bl->status === 'anulacion_solicitada' && $pending = $bl->pendingVoidRequest()): ?>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(auth()->user()->canApproveVoidRequestFrom($pending->requestedBy)): ?>
                <div style="background:#fff8e6; border:1.5px solid #e0b400; border-radius:6px; padding:14px 16px; margin-top:16px;">
                    <div style="font-weight:bold; font-size:14px; margin-bottom:4px;">⏳ Esta solicitud espera tu aprobación</div>
                    <div style="font-size:13px;">
                        <strong><?php echo e($pending->requestedBy->name); ?></strong> solicitó anular este BL el <?php echo e($pending->requested_at->format('d/m/Y H:i')); ?>.<br>
                        Motivo: <?php echo e($pending->requested_reason); ?>

                    </div>
                    <div style="margin-top:12px; display:flex; gap:8px; align-items:center;">
                        <form method="POST" action="<?php echo e(route('bl.void-request.approve', $pending)); ?>" onsubmit="return confirm('¿Apruebas la anulación de este BL? Esta acción no se puede deshacer.');" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-success">✓ Aprobar anulación</button>
                        </form>
                        <form method="POST" action="<?php echo e(route('bl.void-request.reject', $pending)); ?>" style="display:inline-flex; gap:6px;">
                            <?php echo csrf_field(); ?>
                            <input type="text" name="resolution_note" placeholder="Motivo del rechazo (opcional)" style="width:220px;">
                            <button type="submit" class="btn btn-danger">✗ Rechazar</button>
                        </form>
                    </div>
                </div>
            <?php else: ?>
                <div style="background:#fff8e6; border:1px solid #f0d98c; border-radius:6px; padding:12px 16px; margin-top:16px; font-size:13px;">
                    <strong>Anulación en revisión</strong> — solicitada por <?php echo e($pending->requestedBy->name); ?> el <?php echo e($pending->requested_at->format('d/m/Y H:i')); ?>.<br>
                    Motivo: <?php echo e($pending->requested_reason); ?><br>
                    <span style="color:#888;">Esperando aprobación de alguien con rango suficiente (no puedes aprobar tu propia solicitud, ni un auxiliar puede aprobar).</span>
                </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <table style="width:100%; font-size:13px; margin-top:16px;">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($bl->port): ?>
                <tr><td style="padding:5px 0; color:#666; width:180px;">Puerto</td><td><?php echo e($bl->port->code); ?> - <?php echo e($bl->port->name); ?></td></tr>
            <?php else: ?>
                
                <tr><td style="padding:5px 0; color:#666; width:180px;">Puerto de carga</td><td><?php echo e($bl->port_of_loading_text); ?></td></tr>
                <tr><td style="padding:5px 0; color:#666;">Exporting carrier</td><td><?php echo e($bl->exporting_carrier); ?></td></tr>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <tr><td style="padding:5px 0; color:#666;">Shipper</td><td style="white-space:pre-line;"><?php echo e($bl->shipper); ?></td></tr>
            <tr><td style="padding:5px 0; color:#666;">Consignee</td><td style="white-space:pre-line;"><?php echo e($bl->consignee); ?></td></tr>
            <tr><td style="padding:5px 0; color:#666;">Puerto de descarga</td><td><?php echo e($bl->port_of_discharge); ?></td></tr>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($bl->port): ?>
                <tr><td style="padding:5px 0; color:#666;">Buque / Viaje</td><td><?php echo e($bl->ocean_vessel_voy_no); ?></td></tr>
            <?php else: ?>
                <tr><td style="padding:5px 0; color:#666;">On-carriage by</td><td><?php echo e($bl->on_carriage_by); ?></td></tr>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <tr><td style="padding:5px 0; color:#666;">Flete</td><td><?php echo e(ucfirst($bl->freight_type)); ?> — USD <?php echo e(number_format((float) ($bl->freight_total ?? $bl->total_charges ?? 0), 2)); ?></td></tr>
            <tr><td style="padding:5px 0; color:#666;">Creado por</td><td><?php echo e($bl->createdBy->name ?? '—'); ?> el <?php echo e($bl->created_at->format('d/m/Y H:i')); ?></td></tr>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($bl->status === 'anulado'): ?>
                <tr><td style="padding:5px 0; color:#666;">Anulado por</td><td><?php echo e($bl->voidedBy->name ?? '—'); ?> el <?php echo e(optional($bl->voided_at)->format('d/m/Y H:i')); ?></td></tr>
                <tr><td style="padding:5px 0; color:#666;">Motivo</td><td><?php echo e($bl->voided_reason); ?></td></tr>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </table>

        <h3 style="margin-top:24px;">Líneas de carga</h3>
        <table style="width:100%; font-size:12px; border-collapse:collapse;">
            <thead>
                <tr style="text-align:left; border-bottom:1px solid #e2e5e9;">
                    <th style="padding:6px 4px;">Marcas / Contenedor</th>
                    <th>Pkgs</th>
                    <th>Descripción</th>
                    <th>Peso bruto</th>
                    <th>Peso neto</th>
                    <th>CBM</th>
                </tr>
            </thead>
            <tbody>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $bl->cargoItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr style="border-bottom:1px solid #f5f5f5;">
                        <td style="padding:6px 4px;"><?php echo e($item->marks_and_numbers); ?><br><?php echo e($item->container_seal_no); ?></td>
                        <td><?php echo e($item->no_of_pkgs); ?></td>
                        <td><?php echo e($item->description_of_goods); ?></td>
                        <td><?php echo e($item->gross_weight); ?></td>
                        <td><?php echo e($item->net_weight); ?></td>
                        <td><?php echo e($item->measurement_cbm); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </tbody>
        </table>

        <div style="margin-top:24px; display:flex; gap:10px; align-items:center; flex-wrap:wrap;">
            <a href="<?php echo e(route('bl.index')); ?>" class="btn btn-secondary">&larr; Volver al listado</a>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($bl->status === 'borrador'): ?>
                <a href="<?php echo e(route('bl.create', $bl)); ?>" class="btn btn-primary">Continuar editando</a>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($bl->status === 'emitido'): ?>
                <a href="<?php echo e(route('bl.pdf', $bl)); ?>" target="_blank" class="btn btn-secondary">Ver PDF</a>
                <a href="<?php echo e(route('bl.pdf', $bl)); ?>?download=1" class="btn btn-primary">Descargar PDF</a>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('bl.void.request')): ?>
                    <form method="POST" action="<?php echo e(route('bl.void-request', $bl)); ?>" onsubmit="return confirm('¿Confirmas solicitar la anulación de este BL?');" style="display:inline-flex; gap:6px;">
                        <?php echo csrf_field(); ?>
                        <input type="text" name="reason" placeholder="Motivo de la solicitud" required style="width:220px;">
                        <button type="submit" class="btn btn-danger">Solicitar anulación</button>
                    </form>
                <?php endif; ?>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>

        <h3 style="margin-top:28px;">Auditoría</h3>
        <table style="width:100%; font-size:12px; border-collapse:collapse;">
            <thead>
                <tr style="text-align:left; border-bottom:1px solid #e2e5e9;">
                    <th style="padding:6px 4px;">Fecha</th>
                    <th>Usuario</th>
                    <th>Acción</th>
                    <th>Detalle</th>
                </tr>
            </thead>
            <tbody>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $bl->auditLogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr style="border-bottom:1px solid #f5f5f5;">
                        <td style="padding:6px 4px;"><?php echo e($log->created_at->format('d/m/Y H:i')); ?></td>
                        <td><?php echo e($log->user->name ?? '—'); ?></td>
                        <td><?php echo e($log->labelForAction()); ?></td>
                        <td><?php echo e($log->detail); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="4" style="padding:12px; color:#888;">Sin actividad registrada.</td></tr>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </tbody>
        </table>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?><?php /**PATH /var/www/html/resources/views/bl/show.blade.php ENDPATH**/ ?>