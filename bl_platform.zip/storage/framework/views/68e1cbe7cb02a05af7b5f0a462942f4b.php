<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => ['title' => 'Dashboard']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Dashboard']); ?>
    <div class="card">
        <h2>Hola, <?php echo e(auth()->user()->name); ?></h2>
        <p style="color:#666; font-size:13px;">Rol: <?php echo e(auth()->user()->getRoleNames()->first()); ?></p>

        <div style="display:flex; gap:10px; margin:20px 0;">
            <a href="<?php echo e(route('bl.create')); ?>" class="btn btn-success">+ Nuevo BL</a>
            <a href="<?php echo e(route('bl.index')); ?>" class="btn btn-primary">Ver todos los BL</a>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('users.manage')): ?>
                <a href="<?php echo e(route('users.index')); ?>" class="btn btn-secondary">Usuarios</a>
            <?php endif; ?>
        </div>

        <div class="grid-2" style="margin-bottom:24px;">
            <div style="background:#e8f0fe; border-radius:6px; padding:14px; text-align:center;">
                <div style="font-size:26px; font-weight:bold; color:#1e6fb8;"><?php echo e($misBl); ?></div>
                <div style="font-size:12px; color:#888;">Mis BL (creados por mí)</div>
            </div>
            <div style="background:#f4f5f7; border-radius:6px; padding:14px; text-align:center;">
                <div style="font-size:26px; font-weight:bold; color:#555;"><?php echo e($emitidosEsteMes); ?></div>
                <div style="font-size:12px; color:#888;">Emitidos este mes</div>
            </div>
            <div style="background:#f4f5f7; border-radius:6px; padding:14px; text-align:center;">
                <div style="font-size:26px; font-weight:bold; color:#555;"><?php echo e($counts['borrador']); ?></div>
                <div style="font-size:12px; color:#888;">Borradores</div>
            </div>
            <div style="background:#eafaf0; border-radius:6px; padding:14px; text-align:center;">
                <div style="font-size:26px; font-weight:bold; color:#1a7a3c;"><?php echo e($counts['emitido']); ?></div>
                <div style="font-size:12px; color:#888;">Emitidos (activos)</div>
            </div>
            <div style="background:#fff8e6; border-radius:6px; padding:14px; text-align:center;">
                <div style="font-size:26px; font-weight:bold; color:#a67c00;"><?php echo e($counts['anulacion_solicitada']); ?></div>
                <div style="font-size:12px; color:#888;">Anulación solicitada</div>
            </div>
            <div style="background:#fdecea; border-radius:6px; padding:14px; text-align:center;">
                <div style="font-size:26px; font-weight:bold; color:#c0392b;"><?php echo e($counts['anulado']); ?></div>
                <div style="font-size:12px; color:#888;">Anulados</div>
            </div>
        </div>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($porPuerto->isNotEmpty()): ?>
            <h3>BL por puerto</h3>
            <table style="width:100%; font-size:13px; margin-bottom:24px;">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $porPuerto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $port): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr style="border-bottom:1px solid #f0f0f0;">
                        <td style="padding:6px 0; width:60px;"><strong><?php echo e($port->code); ?></strong></td>
                        <td><?php echo e($port->name); ?></td>
                        <td style="text-align:right; font-weight:bold;"><?php echo e($port->bills_of_lading_count); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </table>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($borradoresViejos->isNotEmpty()): ?>
            <h3>⚠️ Borradores sin completar (+3 días)</h3>
            <table style="width:100%; font-size:13px; margin-bottom:24px;">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $borradoresViejos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr style="border-bottom:1px solid #f0f0f0;">
                        <td style="padding:6px 0;"><?php echo e($bl->shipper ?: '(sin shipper aún)'); ?></td>
                        <td><?php echo e($bl->createdBy->name ?? '—'); ?></td>
                        <td><?php echo e($bl->created_at->diffForHumans()); ?></td>
                        <td><a href="<?php echo e(route('bl.create', $bl)); ?>">Continuar &rarr;</a></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </table>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <div class="grid-2" style="margin-bottom:24px;">
            <div>
                <h3>Tendencia mensual (emitidos)</h3>
                <div style="display:flex; align-items:flex-end; gap:6px; height:100px; padding:0 4px;">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $tendenciaMensual; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div style="flex:1; text-align:center;">
                            <div style="background:#1e6fb8; border-radius:3px 3px 0 0; height:<?php echo e($maxTendencia > 0 ? max(4, ($m['total'] / $maxTendencia) * 80) : 4); ?>px;"></div>
                            <div style="font-size:9px; color:#888; margin-top:4px;"><?php echo e($m['label']); ?></div>
                            <div style="font-size:10px; font-weight:bold;"><?php echo e($m['total']); ?></div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
            </div>
            <div>
                <h3>Tiempo promedio creación &rarr; emisión</h3>
                <div style="background:#f4f5f7; border-radius:6px; padding:20px; text-align:center;">
                    <div style="font-size:30px; font-weight:bold; color:#1e6fb8;">
                        <?php echo e($promedioHoras !== null ? $promedioHoras . ' hrs' : '—'); ?>

                    </div>
                    <div style="font-size:12px; color:#888;">
                        <?php echo e($promedioHoras !== null ? 'promedio, sobre BL ya emitidos' : 'aún no hay BL emitidos'); ?>

                    </div>
                </div>
            </div>
        </div>

        <div class="grid-2" style="margin-bottom:24px;">
            <div>
                <h3>Top 5 Shippers</h3>
                <table style="width:100%; font-size:13px;">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $topShippers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr style="border-bottom:1px solid #f0f0f0;">
                            <td style="padding:5px 0;"><?php echo e(\Illuminate\Support\Str::limit($s->shipper, 35)); ?></td>
                            <td style="text-align:right; font-weight:bold;"><?php echo e($s->total); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </table>
            </div>
            <div>
                <h3>Top 5 Consignees</h3>
                <table style="width:100%; font-size:13px;">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $topConsignees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr style="border-bottom:1px solid #f0f0f0;">
                            <td style="padding:5px 0;"><?php echo e(\Illuminate\Support\Str::limit($c->consignee, 35)); ?></td>
                            <td style="text-align:right; font-weight:bold;"><?php echo e($c->total); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </table>
            </div>
        </div>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($pendientesDeAprobar->isNotEmpty()): ?>
            <h3>Pendientes de tu aprobación</h3>
            <table style="width:100%; font-size:13px; margin-bottom:24px;">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $pendientesDeAprobar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr style="border-bottom:1px solid #f0f0f0;">
                        <td style="padding:6px 0;"><?php echo e($vr->billOfLading->bl_number); ?></td>
                        <td>Solicitado por <?php echo e($vr->requestedBy->name); ?></td>
                        <td><a href="<?php echo e(route('bl.show', $vr->bill_of_lading_id)); ?>">Revisar &rarr;</a></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </table>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <h3>Últimos BL</h3>
        <table style="width:100%; font-size:13px;">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $recientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr style="border-bottom:1px solid #f0f0f0;">
                    <td style="padding:6px 0;"><?php echo e($bl->bl_number ?? '(borrador)'); ?></td>
                    <td><?php echo e($bl->port->code ?? $bl->port_of_loading_text ?? '—'); ?></td>
                    <td><?php echo e(ucfirst(str_replace('_', ' ', $bl->status))); ?></td>
                    <td><a href="<?php echo e($bl->status === 'borrador' ? route('bl.create', $bl) : route('bl.show', $bl)); ?>">Ver &rarr;</a></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </table>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?><?php /**PATH /var/www/html/resources/views/dashboard.blade.php ENDPATH**/ ?>